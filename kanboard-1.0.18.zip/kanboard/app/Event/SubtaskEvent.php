<?php

namespace Event;

class SubtaskEvent extends GenericEvent
{
}
