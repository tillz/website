<div id="user-calendar"
     data-check-url="<?= $this->url->href('calendar', 'user') ?>"
     data-user-id="<?= $user['id'] ?>"
     data-save-url="<?= $this->url->href('calendar', 'save') ?>"
>
</div>