<?php

namespace Event;

class TaskEvent extends GenericEvent
{
}
