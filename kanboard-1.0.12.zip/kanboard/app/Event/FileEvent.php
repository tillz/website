<?php

namespace Event;

class FileEvent extends GenericEvent
{
}
