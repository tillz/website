<section id="main">

    <div class="page-header board">
        <h2>
            <?= t('Project "%s"', $current_project_name) ?>
        </h2>
        <ul>
            <?php foreach ($projects as $project_id => $project_name): ?>
            <?php if ($project_id != $current_project_id): ?>
            <li>
                <a href="?controller=board&amp;action=show&amp;project_id=<?= $project_id ?>"><?= Helper\escape($project_name) ?></a>
            </li>
            <?php endif ?>
            <?php endforeach ?>
        </ul>
    </div>

    <div class="project-menu">
        <ul>
            <li><a href="?controller=project&amp;action=tasks&amp;project_id=<?= $current_project_id ?>"><?= t('completed tasks') ?></a></li>
        </ul>
    </div>

    <?php if (empty($columns)): ?>
        <p class="alert alert-error"><?= t('There is no column in your project!') ?></p>
    <?php else: ?>

        <table id="board" data-project-id="<?= $current_project_id ?>">
            <tr>
                <?php $column_with = round(100 / count($columns), 2); ?>
                <?php foreach ($columns as $column): ?>
                <th width="<?= $column_with ?>%">
                    <a href="?controller=task&amp;action=create&amp;project_id=<?= $column['project_id'] ?>&amp;column_id=<?= $column['id'] ?>" title="<?= t('Add a new task') ?>">+</a>
                    <?= Helper\escape($column['title']) ?>
                    <?php if ($column['task_limit']): ?>
                        <span title="<?= t('Task limit') ?>" class="task-limit">
                            (
                             <span id="task-number-column-<?= $column['id'] ?>"><?= count($column['tasks']) ?></span>
                             /
                             <?= Helper\escape($column['task_limit']) ?>
                            )
                        </span>
                    <?php endif ?>
                </th>
                <?php endforeach ?>
            </tr>
            <tr>
                <?php foreach ($columns as $column): ?>
                <td
                    id="column-<?= $column['id'] ?>"
                    class="column <?= $column['task_limit'] && count($column['tasks']) > $column['task_limit'] ? 'task-limit-warning' : '' ?>"
                    data-column-id="<?= $column['id'] ?>"
                    data-task-limit="<?= $column['task_limit'] ?>"
                    dropzone="copy">
                    <?php foreach ($column['tasks'] as $task): ?>
                    <div class="draggable-item" draggable="true">
                        <div class="task task-<?= $task['color_id'] ?>" data-task-id="<?= $task['id'] ?>">

                            <a href="?controller=task&amp;action=show&amp;task_id=<?= $task['id'] ?>" title="<?= t('View this task') ?>">#<?= $task['id'] ?></a> -

                            <span class="task-user">
                            <?php if (! empty($task['owner_id'])): ?>
                                <a href="?controller=board&amp;action=assign&amp;task_id=<?= $task['id'] ?>" title="<?= t('Change assignee') ?>"><?= t('Assigned to %s', $task['username']) ?></a>
                            <?php else: ?>
                                <a href="?controller=board&amp;action=assign&amp;task_id=<?= $task['id'] ?>" title="<?= t('Change assignee') ?>" class="task-nobody"><?= t('No body assigned') ?></a>
                            <?php endif ?>
                            </span>

                            <?php if ($task['score']): ?>
                                <span class="task-score"><?= Helper\escape($task['score']) ?></span>
                            <?php endif ?>

                            <div class="task-title">
                                <?= Helper\escape($task['title']) ?>
                            </div>

                        </div>
                    </div>
                    <?php endforeach ?>
                </td>
                <?php endforeach ?>
            </tr>
        </table>

    <?php endif ?>

</section>

<script type="text/javascript" src="assets/js/board.js"></script>