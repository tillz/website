<?php

namespace Kanboard\Auth;

use Kanboard\Core\Base;
use Kanboard\Model\User;
use Kanboard\Event\AuthEvent;

/**
 * Database authentication
 *
 * @package  auth
 * @author   Frederic Guillot
 */
class Database extends Base
{
    /**
     * Backend name
     *
     * @var string
     */
    const AUTH_NAME = 'Database';

    /**
     * Authenticate a user
     *
     * @access public
     * @param  string  $username  Username
     * @param  string  $password  Password
     * @return boolean
     */
    public function authenticate($username, $password)
    {
        $user = $this->db
                    ->table(User::TABLE)
                    ->eq('username', $username)
                    ->eq('disable_login_form', 0)
                    ->eq('is_ldap_user', 0)
                    ->findOne();

        if (is_array($user) && password_verify($password, $user['password'])) {
            $this->userSession->initialize($user);
            $this->container['dispatcher']->dispatch('auth.success', new AuthEvent(self::AUTH_NAME, $user['id']));
            return true;
        }

        return false;
    }
}
