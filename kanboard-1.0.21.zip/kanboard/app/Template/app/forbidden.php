<section id="main">
    <p class="alert alert-error">
        <?= t('Access Forbidden') ?>
    </p>
</section>