<section id="main">
    <p class="alert alert-error">
        <?= t('Sorry, I didn\'t found this information in my database!') ?>
    </p>
</section>