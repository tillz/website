<?php

namespace Core\ObjectStorage;

use Exception;

class ObjectStorageException extends Exception
{
}
