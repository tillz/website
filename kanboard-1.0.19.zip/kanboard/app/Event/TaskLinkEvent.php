<?php

namespace Event;

class TaskLinkEvent extends GenericEvent
{
}
