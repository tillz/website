<section id="main">
    <section class="sidebar-container" id="config-section">

        <?= $this->render($sidebar_template) ?>

        <div class="sidebar-content">
            <?= $content_for_sublayout ?>
        </div>
    </section>
</section>