<section id="main">
    <section class="sidebar-container" id="config-section">

        <?= $this->render('config/sidebar') ?>

        <div class="sidebar-content">
            <?= $config_content_for_layout ?>
        </div>
    </section>
</section>