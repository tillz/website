<div id="user-calendar"
     data-check-url="<?= $this->u('calendar', 'user') ?>"
     data-user-id="<?= $user['id'] ?>"
     data-save-url="<?= $this->u('calendar', 'save') ?>"
>
</div>