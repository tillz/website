<?php

namespace Kanboard\Event;

class TaskEvent extends GenericEvent
{
}
