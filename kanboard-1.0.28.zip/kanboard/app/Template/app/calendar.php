<div id="calendar"
     data-check-url="<?= $this->url->href('calendar', 'user', array('user_id' => $user['id'])) ?>"
     data-save-url="<?= $this->url->href('calendar', 'save') ?>"
>
</div>
