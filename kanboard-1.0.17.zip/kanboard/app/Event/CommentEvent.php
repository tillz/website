<?php

namespace Event;

class CommentEvent extends GenericEvent
{
}
